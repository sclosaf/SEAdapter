/*
 * @(#)defines.h	1.7 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _HPROF_DEFINES_H
#define _HPROF_DEFINES_H

#include <sys/types.h>
#include <time.h>
#include "typedefs.h"

#ifndef _WIN32
typedef uint32_t         UINT32;
typedef int32_t          INT32;
typedef size_t           SIZE_T;
typedef ssize_t          SSIZE_T;
#endif
typedef intptr_t         INTPTR_T;
typedef uintptr_t        UINTPTR_T;

#endif
