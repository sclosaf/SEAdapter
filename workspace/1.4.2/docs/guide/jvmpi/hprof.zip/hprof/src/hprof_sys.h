/*
 * @(#)hprof_sys.h	1.8 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _HPROF_SYS_H
#define _HPROF_SYS_H

#include "defines.h"

/* Defined in platform-specific code */

int hprof_send(int s, const char *msg, int len, int flags);
int hprof_write(int filedes, const void *buf, SIZE_T nbyte);
jint hprof_get_milliticks(void);
jlong hprof_get_timemillis(void);
void hprof_get_prelude_path(char *path);

#endif /* _HPROF_SYS_H */
