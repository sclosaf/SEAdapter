/*
 * @(#)hprof_cpu.h	1.5 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _HPROF_CPUSAMPLE_H
#define _HPROF_CPUSAMPLE_H

struct hprof_objmap_t;

void hprof_cpu_sample_off(struct hprof_objmap_t *thread_id);
void hprof_cpu_sample_on(struct hprof_objmap_t *thread_id);
void hprof_start_cpu_sampling_thread(void);

#endif /* _HPROF_CPUSAMPLE_H */
