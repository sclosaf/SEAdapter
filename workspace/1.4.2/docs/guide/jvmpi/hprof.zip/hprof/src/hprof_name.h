/*
 * @(#)hprof_name.h	1.8 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _HPROF_NAME_H
#define _HPROF_NAME_H

/* Names */
typedef struct hprof_name_t {
    int marked;                        /* been written to the output? */
    const char *name;                  /* name */
} hprof_name_t;

void hprof_name_table_init(void);
void hprof_output_name(hprof_name_t *name);
hprof_name_t * hprof_intern_name(const char *name);

#ifdef HASH_STATS
void hprof_print_name_hash_stats(FILE *fp);
#endif /* HASH_STATS */
#ifdef WATCH_ALLOCS
void hprof_free_name_table(void);
#endif /* WATCH_ALLOCS */

#endif /* _HPROF_NAME_H */
