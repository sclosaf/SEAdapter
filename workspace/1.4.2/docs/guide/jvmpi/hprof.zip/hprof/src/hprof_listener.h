/*
 * @(#)hprof_listener.h	1.5 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _HPROF_LISTENER_H
#define _HPROF_LISTENER_H

void hprof_start_listener_thread(void);

#endif
