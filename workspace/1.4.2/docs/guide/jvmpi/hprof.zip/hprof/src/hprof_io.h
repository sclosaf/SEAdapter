/*
 * @(#)hprof_io.h	1.6 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _HPROF_IO_H
#define _HPROF_IO_H

void hprof_write_header(unsigned char type, jint length);
void hprof_write_dev(void *buf, int len);
void hprof_write_raw(void *buf, int len);
void hprof_flush(void);
void hprof_printf(char *fmt, ...);
void hprof_write_current_ticks();
void hprof_write_u4(unsigned int i);
void hprof_write_u2(unsigned short i);
void hprof_write_u1(unsigned char i);
void hprof_write_id(void *p);
void hprof_io_setup(void);
#ifdef WATCH_ALLOCS
void hprof_io_free(void);
#endif /* WATCH_ALLOCS */

void hprof_dump_seek(char *ptr);
char * hprof_dump_cur(void);
void hprof_dump_read(void *buf, int size);
void * hprof_dump_read_id(void);
unsigned int hprof_dump_read_u4(void);
unsigned short hprof_dump_read_u2(void);
unsigned char hprof_dump_read_u1(void);

#endif /* _HPROF_IO_H */
