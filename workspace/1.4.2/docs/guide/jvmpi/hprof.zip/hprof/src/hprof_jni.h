/*
 * @(#)hprof_jni.h	1.5 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _HPROF_JNI_H
#define _HPROF_JNI_H

/* JNI global refs */
typedef struct hprof_globalref_t {
    struct hprof_globalref_t *next;    /* next global ref */
    jobject ref_id;                    /* referece ID */
    struct hprof_objmap_t *obj_id;     /* object ID */
    unsigned int trace_serial_num;     /* trace where the ref was alloced */
} hprof_globalref_t;

hprof_globalref_t * hprof_globalref_find(jobject ref_id);
void hprof_jni_globalref_alloc_event(JNIEnv *env_id, jobjectID obj_id, jobject ref_id);
void hprof_jni_globalref_free_event(JNIEnv *env_id, jobject ref_id);

#endif /* _HPROF_JNI_H */
