/*
 * @(#)jlong.h	1.8 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _JLONG_H_
#define _JLONG_H_

#include "jlong_md.h"

#endif
