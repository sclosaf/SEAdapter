/*
 * @(#)hprof_heapdump.h	1.7 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _HPROF_HEAPDUMP_H
#define _HPROF_HEAPDUMP_H

void hprof_heap_dump_event(char *begin_roots,
			   char *end_objects,
			   int num_traces,
			   JVMPI_CallTrace *traces);

void hprof_get_heap_dump(void);
void hprof_object_dump_event(char *data);

#endif /* _HPROF_HEAPDUMP_H */
