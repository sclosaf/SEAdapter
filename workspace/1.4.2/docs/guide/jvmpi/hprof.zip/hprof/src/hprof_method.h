/*
 * @(#)hprof_method.h	1.7 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _HPROF_METHOD_H
#define _HPROF_METHOD_H

void hprof_method_table_init(void);
hprof_method_t * hprof_lookup_method(jmethodID method_id);
hprof_method_t * hprof_intern_method(JVMPI_Method *jmethod, hprof_class_t *hclass);
void hprof_method_entry_event(JNIEnv *env_id, jmethodID method_id);
void hprof_method_exit_event(JNIEnv *env_id, jmethodID method_id);

#ifdef HASH_STATS
void hprof_print_method_hash_stats(FILE *fp);
#endif /* HASH_STATS */
#ifdef WATCH_ALLOCS
void hprof_free_method_table(void);
#endif /* WATCH_ALLOCS */

#endif /* _HPROF_METHOD_H */
