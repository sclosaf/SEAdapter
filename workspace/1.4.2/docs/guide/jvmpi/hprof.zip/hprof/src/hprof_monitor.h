/*
 * @(#)hprof_monitor.h	1.9 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _HPROF_MONITOR_H
#define _HPROF_MONITOR_H

#include "hprof_name.h"

void hprof_raw_monitor_table_init(void);
void hprof_contended_monitor_table_init(void);
void hprof_clear_contended_monitor_table(void);
void hprof_raw_monitor_event(JVMPI_Event *event,
			     const char *name,
			     JVMPI_RawMonitor mid);
void hprof_monitor_event(JVMPI_Event *event, jobjectID obj);
void hprof_monitor_wait_event(JVMPI_Event *event, jobjectID obj,
			      jlong timeout);
void hprof_dump_monitors(void);
void hprof_monitor_dump_event(JVMPI_Event *event);
void hprof_output_cmon_times(float cutoff);
#ifdef HASH_STATS
void hprof_print_contended_monitor_hash_stats(FILE *fp);
void hprof_print_raw_monitor_hash_stats(FILE *fp);
#endif /* HASH_STATS */
#ifdef WATCH_ALLOCS
void hprof_free_contended_monitor_table(void);
void hprof_free_raw_monitor_table(void);
#endif /* WATCH_ALLOCS */

typedef struct {
    hprof_name_t *name;
    JVMPI_RawMonitor id;
} hprof_raw_monitor_t;

typedef struct {
    jint type;                        /* Java or Raw? */
    void *mon_info;                   /* (hprof_objmap_t *) or
					 (hprof_raw_monitor_t *) */
    unsigned int trace_serial_num;    /* trace where contention occured */
    jlong time;                       /* time associated with the contention */
    jint num_hits;                    /* # of times this monitor is contended 
					 at this trace */
} hprof_contended_monitor_t;

/* Auxilary data structure used for collecting contended monitor info. */
typedef struct {
    hprof_contended_monitor_t **cmons;               
    int index;
    jlong total_time;
} hprof_cmon_iterate_t;

#endif /* _HPROF_MONITOR_H */
