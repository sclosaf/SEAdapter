/*
 * @(#)hprof_hash.h	1.10 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _HPROF_HASH_H
#define _HPROF_HASH_H

/* Generic support for hash tables */

typedef struct hprof_bucket_t {
    struct hprof_bucket_t *next;
    void *content;
} hprof_bucket_t;

typedef struct {
#ifdef WATCH_ALLOCS
    unsigned int table_type;           /* ALLOC_HASH_... value */
#endif /* WATCH_ALLOCS */
    unsigned int n_entries;            /* total buckets in the table */
    unsigned int size;                 /* size of the top-level table */
    hprof_bucket_t **entries;
    UINTPTR_T (*hash_f)(void *);    /* hash function */
    unsigned int (*size_f)(void *);    /* content size */
    int (*compare_f)(void *, void *);  /* comparison function */
#ifdef HASH_STATS
    unsigned int table_deletes;        /* # of entries deleted */
    unsigned int table_hits;           /* # of hash hits */
    unsigned int table_misses;         /* # of hash misses */
#endif /* HASH_STATS */
} hprof_hash_t;

void hprof_hash_init(int table_type,
		     hprof_hash_t *table,
		     int size,
		     UINTPTR_T (*hash_f)(void *),
		     unsigned int (*size_f)(void *),
		     int (*compare_f)(void *, void *));
void * hprof_hash_iterate(hprof_hash_t *table,
			  void * (*f)(void *, void *),
			  void *arg);
void hprof_hash_remove(hprof_hash_t *table,
		       int (*f)(void *, void *),
		       void *arg);
void hprof_rehash(hprof_hash_t *table,
		  int (*f)(void *, void *),
		  void *arg);
void hprof_hash_removeall(hprof_hash_t *table);
void * hprof_hash_lookup(hprof_hash_t *table, void *new);
void * hprof_hash_put(hprof_hash_t *table, void *new);
void * hprof_hash_intern(hprof_hash_t *table, void *new);
#ifdef HASH_STATS
void hprof_print_global_hash_stats(FILE *fp);
void hprof_print_tbl_hash_stats(FILE *fp, hprof_hash_t *table);
#endif /* HASH_STATS */
#ifdef WATCH_ALLOCS
void hprof_hash_free(hprof_hash_t *table);
#endif /* WATCH_ALLOCS */

#endif /* _HPROF_HASH_H */
