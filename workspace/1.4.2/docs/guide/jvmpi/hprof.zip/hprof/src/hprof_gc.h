/*
 * @(#)hprof_gc.h	1.5 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _HPROF_GC_H
#define _HPROF_GC_H

void hprof_gc_start_event(JNIEnv *env_id);
void hprof_gc_finish_event (JNIEnv *env_id, jlong used_objects,
			    jlong used_object_space, jlong total_object_space);

#endif /* _HPROF_GC_H */
