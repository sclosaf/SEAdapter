/*
 * @(#)hprof_setup.h	1.5 03/01/23
 *
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _HPROF_SETUP_H
#define _HPROF_SETUP_H

void hprof_init_setup(char *profiler_options);

#endif /* _HPROF_SETUP_H */
